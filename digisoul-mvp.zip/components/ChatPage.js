import { useState } from 'react';
import axios from 'axios';

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    const res = await axios.post("/api/chat", { message: input });
    setMessages([...messages, { role: "user", content: input }, res.data]);
    setInput("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>DigiSoul MVP Chat</h1>
      <div style={{ marginBottom: 10 }}>
        {messages.map((msg, i) => (
          <div key={i}><b>{msg.role}:</b> {msg.content}</div>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type your message..."
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}