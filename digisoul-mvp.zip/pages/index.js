import ChatPage from '../components/ChatPage';

export default function Home() {
  return <ChatPage />;
}