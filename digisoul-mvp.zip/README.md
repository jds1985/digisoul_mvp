# DigiSoul MVP

Memory chat prototype using Next.js + Firebase + OpenAI.

## How to Run
1. Add `.env.local` file
2. `npm install`
3. `npm run dev`
4. Deploy to Vercel